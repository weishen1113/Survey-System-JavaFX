package com.survey.surveysystem;

import java.io.IOException;
import javafx.fxml.FXML;

public class PrimaryController {
}
