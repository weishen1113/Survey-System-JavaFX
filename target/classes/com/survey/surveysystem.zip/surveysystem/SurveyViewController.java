/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package com.survey.surveysystem;

import com.survey.surveysystem.file.ReadFile;
import com.survey.surveysystem.file.WriteFile;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;

/**
 * FXML Controller class
 *
 * @author a
 */
public class SurveyViewController implements Initializable {

    /**
     * Initializes the controller class.
     */
    public VBox root;
    private String surveyId;
    private String surveyName;
    private String backPage;
    private String txtQAns1Value;
    private String txtQAns2Value;
    private String txtQAns3Value;
    private String txtQAns4Value;
    
    public void setTxtQAnsValues(String txtQAns1, String txtQAns2, String txtQAns3, String txtQAns4) {
        this.txtQAns1Value = txtQAns1;
        this.txtQAns2Value = txtQAns2;
        this.txtQAns3Value = txtQAns3;
        this.txtQAns4Value = txtQAns4;
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {

    }

    @FXML
    private Text txtTitle;

    @FXML
    void OnTest(ActionEvent event) {

    }

    @FXML
    void onBackClick(ActionEvent event) {
        try {
            App.setRoot(backPage);
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    public void start() {
        txtTitle.setText(surveyName);
        ReadFile readFile = new ReadFile("questions.txt");
        int count = 1;
        for (String line : readFile.ReadFileByLines()) {
            String[] s = line.split(";");
            if (s.length >=5 ) {
                if (s[2].equals(surveyId)) {
                    Text text = new Text("Q" + count + " " + s[3]);
                    TextField textF = new TextField();
                    ToggleGroup toggleGroup = new ToggleGroup();
                    RadioButton c1 = new RadioButton();
                    RadioButton c2 = new RadioButton();
                    RadioButton c3 = new RadioButton();
                    RadioButton c4 = new RadioButton();
                    RadioButton checkYes = new RadioButton("Yes");
                    RadioButton checkNo = new RadioButton("No");

                    c1.setToggleGroup(toggleGroup);
                    c2.setToggleGroup(toggleGroup);
                    c3.setToggleGroup(toggleGroup);
                    c4.setToggleGroup(toggleGroup);
                    checkYes.setToggleGroup(toggleGroup);
                    checkNo.setToggleGroup(toggleGroup);

                    textF.setPromptText("Answer");

                    HBox hbox = new HBox();
                    hbox.getChildren().add(c1);
                    hbox.getChildren().add(c2);
                    hbox.getChildren().add(c3);
                    hbox.getChildren().add(c4);
                    hbox.setSpacing(25);

                    HBox polarBox = new HBox();
                    polarBox.getChildren().add(checkYes);
                    polarBox.getChildren().add(checkNo);
                    polarBox.setSpacing(25);

                    VBox vbox = new VBox();
                    Button dynamicButton = new Button("Submit");
                    dynamicButton.setOnAction(event -> {
                        System.out.println("aaaa " + surveyId);
                    });
                    vbox.getChildren().add(text);
                    if (s[4].equals("MCQ")) {
                        vbox.getChildren().add(hbox);
                        c1.setText(s[5]);
                        c2.setText(s[6]);
                        c3.setText(s[7]);
                        c4.setText(s[8]);
                    } else if (s[4].equals("PolarQuestion")) {
                        vbox.getChildren().add(polarBox);
                    } else {
                        vbox.getChildren().add(textF);
                        //root.getChildren().add(dynamicButton);
                    }
                    root.getChildren().add(vbox);
                    root.setSpacing(25);
                    count++;
                }
            }
        }
    }

    public void setSurveyId(String surveyId) {
        this.surveyId = surveyId;
    }

    public void setSurveyName(String surveyName) {
        this.surveyName = surveyName;
    }

    @FXML
    void onSubmit(ActionEvent event) {
        WriteFile writeFile = new WriteFile("responses.txt");
        writeFile.writeFile(surveyId.concat(";").concat("submited"));
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "Your response is submited");
        alert.show();
    }

    public void setBackPage(String backPage) {
        this.backPage = backPage;
    }

}
